<?php
$name='TrebuchetMS';
$type='TTF';
$desc=array (
  'Ascent' => 939,
  'Descent' => -222,
  'CapHeight' => 939,
  'Flags' => 4,
  'FontBBox' => '[-86 -262 1082 943]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-127;
$ut=62;
$ttffile='/var/www-domains/vtiger-crm.sk/sub/ext4you/PDFMaker/520/modules/PDFMaker/mpdf/ttfonts/trebuc.ttf';
$TTCfontID='0';
$originalsize=136172;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='trebuchetms';
$panose='8 2 2 11 6 3 2 2 2 2 2 4';
?>