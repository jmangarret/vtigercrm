<?php
  include("modules/PDFMaker/mpdf/mpdf.php");
  
  class mpdfPDFMaker extends mPDF
  {

  }
?>