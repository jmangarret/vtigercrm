<?php
$name='ComicSansMSBold';
$type='TTF';
$desc=array (
  'Ascent' => 1102,
  'Descent' => -292,
  'CapHeight' => 1102,
  'Flags' => 262148,
  'FontBBox' => '[-112 -292 1229 1102]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 500,
);
$up=-133;
$ut=85;
$ttffile='/var/www/vhosts/crm.tuagencia24.com/html/modules/PDFMaker/mpdf/ttfonts/comicbd.ttf';
$TTCfontID='0';
$originalsize=111476;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='comicsansmsB';
$panose='10 8 3 15 9 2 3 3 2 2 2 4';
?>