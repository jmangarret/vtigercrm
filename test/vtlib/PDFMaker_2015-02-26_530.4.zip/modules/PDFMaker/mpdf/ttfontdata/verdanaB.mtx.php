<?php
$name='VerdanaBold';
$type='TTF';
$desc=array (
  'Ascent' => 1005,
  'Descent' => -210,
  'CapHeight' => 1005,
  'Flags' => 262148,
  'FontBBox' => '[-73 -208 1707 1000]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 1000,
);
$up=-68;
$ut=103;
$ttffile='/var/www-domains/vtiger-crm.sk/sub/ext4you/PDFMaker/520/modules/PDFMaker/mpdf/ttfonts/verdanab.ttf';
$TTCfontID='0';
$originalsize=137616;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='verdanaB';
$panose='8 0 2 11 8 4 3 5 4 4 2 4';
?>