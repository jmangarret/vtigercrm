<?php
$name='ComicSansMS';
$type='TTF';
$desc=array (
  'Ascent' => 1102,
  'Descent' => -292,
  'CapHeight' => 1102,
  'Flags' => 4,
  'FontBBox' => '[-93 -312 1187 1102]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-133;
$ut=85;
$ttffile='/var/www-domains/vtiger-crm.sk/sub/ext4you/PDFMaker/520/modules/PDFMaker/mpdf/ttfonts/comic.ttf';
$TTCfontID='0';
$originalsize=127596;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='comicsansms';
$panose='10 8 3 15 7 2 3 3 2 2 2 4';
?>