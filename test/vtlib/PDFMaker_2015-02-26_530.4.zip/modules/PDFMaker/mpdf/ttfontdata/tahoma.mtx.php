<?php
$name='Tahoma';
$type='TTF';
$desc=array (
  'Ascent' => 1000,
  'Descent' => -207,
  'CapHeight' => 1000,
  'Flags' => 4,
  'FontBBox' => '[-600 -207 1338 1034]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$up=-83;
$ut=63;
$ttffile='/var/www-domains/vtiger-crm.sk/sub/ext4you/PDFMaker/520/modules/PDFMaker/mpdf/ttfonts/tahoma.ttf';
$TTCfontID='0';
$originalsize=379588;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='tahoma';
$panose='8 0 2 11 6 4 3 5 4 4 2 4';
?>