<?php
$name='Georgia';
$type='TTF';
$desc=array (
  'Ascent' => 917,
  'Descent' => -219,
  'CapHeight' => 917,
  'Flags' => 4,
  'FontBBox' => '[-173 -217 1167 912]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$up=-88;
$ut=49;
$ttffile='/var/www-domains/vtiger-crm.sk/sub/ext4you/PDFMaker/520/modules/PDFMaker/mpdf/ttfonts/georgia.ttf';
$TTCfontID='0';
$originalsize=155068;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='georgia';
$panose='4 3 2 4 5 2 5 4 5 2 3 3';
?>