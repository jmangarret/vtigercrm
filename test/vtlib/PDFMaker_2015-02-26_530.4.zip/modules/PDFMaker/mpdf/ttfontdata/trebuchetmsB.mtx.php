<?php
$name='TrebuchetMSBold';
$type='TTF';
$desc=array (
  'Ascent' => 939,
  'Descent' => -222,
  'CapHeight' => 939,
  'Flags' => 262148,
  'FontBBox' => '[-101 -270 1130 980]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 500,
);
$up=-127;
$ut=98;
$ttffile='/var/www/vhosts/crm.tuagencia24.com/html/modules/PDFMaker/mpdf/ttfonts/trebucbd.ttf';
$TTCfontID='0';
$originalsize=126376;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='trebuchetmsB';
$panose='8 2 2 11 7 3 2 2 2 2 2 4';
?>