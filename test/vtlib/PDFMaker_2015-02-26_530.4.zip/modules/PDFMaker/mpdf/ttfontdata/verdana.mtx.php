<?php
$name='Verdana';
$type='TTF';
$desc=array (
  'Ascent' => 1005,
  'Descent' => -210,
  'CapHeight' => 1005,
  'Flags' => 4,
  'FontBBox' => '[-50 -207 1447 1000]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$up=-88;
$ut=59;
$ttffile='/var/www-domains/vtiger-crm.sk/sub/ext4you/PDFMaker/520/modules/PDFMaker/mpdf/ttfonts/verdana.ttf';
$TTCfontID='0';
$originalsize=171792;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='verdana';
$panose='8 0 2 11 6 4 3 5 4 4 2 4';
?>