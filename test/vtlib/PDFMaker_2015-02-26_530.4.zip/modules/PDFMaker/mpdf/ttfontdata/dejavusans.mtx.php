<?php
$name='DejaVuSans';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 4,
  'FontBBox' => '[-1021 -415 1681 1167]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 600,
);
$up=-63;
$ut=44;
$ttffile='/var/www-domains/vtiger-crm.sk/sub/ext4you/PDFMaker/520/modules/PDFMaker/mpdf/ttfonts/DejaVuSans.ttf';
$TTCfontID='0';
$originalsize=633604;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusans';
$panose='0 0 2 11 6 3 3 8 4 2 2 4';
?>