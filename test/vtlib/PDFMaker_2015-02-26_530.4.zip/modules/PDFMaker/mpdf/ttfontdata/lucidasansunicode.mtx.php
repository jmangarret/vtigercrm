<?php
$name='LucidaSansUnicode';
$type='TTF';
$desc=array (
  'Ascent' => 1097,
  'Descent' => -440,
  'CapHeight' => 1097,
  'Flags' => 4,
  'FontBBox' => '[-615 -440 1384 1145]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 750,
);
$up=-100;
$ut=50;
$ttffile='/var/www-domains/vtiger-crm.sk/sub/ext4you/PDFMaker/520/modules/PDFMaker/mpdf/ttfonts/Lucida.ttf';
$TTCfontID='0';
$originalsize=323980;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='lucidasansunicode';
$panose='0 0 2 11 6 2 3 5 4 2 2 4';
?>