<?php
$name='TahomaBold';
$type='TTF';
$desc=array (
  'Ascent' => 1000,
  'Descent' => -207,
  'CapHeight' => 1000,
  'Flags' => 262148,
  'FontBBox' => '[-698 -207 1625 1065]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 1000,
);
$up=-70;
$ut=98;
$ttffile='/var/www/vhosts/crm.tuagencia24.com/html/modules/PDFMaker/mpdf/ttfonts/tahomabd.ttf';
$TTCfontID='0';
$originalsize=352020;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='tahomaB';
$panose='8 0 2 11 8 4 3 5 4 4 2 4';
?>